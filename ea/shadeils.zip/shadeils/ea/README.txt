=========================================
Evolutionary Algorithm package for Python
=========================================

ea provides a package for several Evolutionary Algorithms for Python.
