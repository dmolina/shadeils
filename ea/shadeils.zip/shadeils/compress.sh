cd ..
zip -r --exclude=*shadeils-env/* --exclude=*.csv --exclude=*results* --exclude=*__pycache__* shadeils.zip shadeils
cd -
mv ../shadeils.zip .
